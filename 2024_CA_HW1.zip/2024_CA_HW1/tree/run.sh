spike --isa=RV32IM /opt/riscv/bin/pk ./tree 1 2 3 _ 4
