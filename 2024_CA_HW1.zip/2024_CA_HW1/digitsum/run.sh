spike --isa=RV32IM /opt/riscv/bin/pk ./digitsum 123 456
