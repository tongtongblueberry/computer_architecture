#ifndef digitsum_H
#define digitsum_H

int digitsum(const int lhs, const int rhs);

#endif
