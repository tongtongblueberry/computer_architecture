#ifndef FIBONACCI_H
#define FIBONACCI_H

int fibonacci(const unsigned int n);

#endif
