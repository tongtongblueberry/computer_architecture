spike --isa=RV32IM /opt/riscv/bin/pk ./fibonacci 10
